package com.txtlearn.blackjack01;

public enum Suit {
    CLUB,DIAMOND,SPADE,HEART
}
