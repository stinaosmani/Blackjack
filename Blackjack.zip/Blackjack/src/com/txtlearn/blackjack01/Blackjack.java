package com.txtlearn.blackjack01;

import java.util.Scanner;

public class Blackjack {
    public static void main(String[] args) {
        System.out.println("Pershendetje! Mire se vini ne Blackjack!");
        Deck playingDeck = new Deck();
        playingDeck.createFullDeck();
        playingDeck.shuffle();

        Deck playerDeck = new Deck();
        Deck dealerDeck = new Deck();

        double playerMoney = 100.00;
        Scanner scan = new Scanner(System.in);

        while (playerMoney > 0) {
            //munet me lujt
            System.out.println("Ju keni "+ playerMoney+ "euro. Sa do te doni t'i fusni ne loje?");
            double playerBet= scan.nextDouble();
            if(playerBet>playerMoney){
                System.out.println("Loja perfundoi sepse ju nuk keni aq shume para sa doni te vini bast.");
                break;
            }
            boolean endRound=false;

            playerDeck.draw(playingDeck);
            playerDeck.draw(playingDeck);

            dealerDeck.draw(playingDeck);
            dealerDeck.draw(playingDeck);

            while(true){
                System.out.println("Letrat tuaja: ");
                System.out.println(playerDeck.toString());
                System.out.println("Letrat tuaja kane vleren :"+playerDeck.cardsValue());

                System.out.println("Letrat e dealer-it kane vleren:"+ dealerDeck.getCard(0).toString() + " dhe nje leter e fshehur.");

                System.out.println("A do deshironi te terhiqeni(1) apo te luani(2)?");
                int response =scan.nextInt();

                if(response==1){
                    playerDeck.draw(playingDeck);
                    System.out.println("Ju terheqni nje: "+ playerDeck.getCard(playerDeck.deckSize()-1).toString());
              if(playerDeck.cardsValue()>21){
                  System.out.println("Vlera per momentin:"+ playerDeck.cardsValue());
                  playerMoney -= playerBet;
                  endRound=true;

              }
                }
                if(response==2) {
                    break;
                }
            }
            System.out.println("Letrat e dealer: "+ dealerDeck.toString());
            if((dealerDeck.cardsValue()>playerDeck.cardsValue())&& endRound==false){
                System.out.println("Dealer fiton");
                playerMoney-=playerBet;
            }
while((dealerDeck.cardsValue()<17)&& endRound== false){
    dealerDeck.draw(playingDeck);
    System.out.println("Dealeri draws: " + dealerDeck.getCard(dealerDeck.deckSize()-1).toString());
}
            System.out.println("Dealer ka: "+ dealerDeck.cardsValue());
if((dealerDeck.cardsValue()>21)&& endRound== false){
    System.out.println("Ju keni fituar!");
    playerMoney+=playerBet;
    endRound=true;
}
if((playerDeck.cardsValue()== dealerDeck.cardsValue())&& endRound== false){
    System.out.println("Barazim.");
    endRound= true;

}
    if((playerDeck.cardsValue()> dealerDeck.cardsValue())&& endRound== false){
        System.out.println("Ju fituat!");
        playerMoney+=playerBet;
        endRound=true;
    }
    else if(endRound== false){
        System.out.println("Ju humbet!");
        playerMoney-= playerBet;
        endRound=true;

    }
    playerDeck.moveAllToDeck(playingDeck);
    dealerDeck.moveAllToDeck(playingDeck);
            System.out.println("Fundi i lojes.");
        }
        System.out.println("Keni humbur! Nuk keni me para per te vazhduar lojen.");
    }
}


